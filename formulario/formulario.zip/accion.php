<html>
  <head>
    <title>DatosCapturados1</title>
       <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <center><h3><br><hr>DATOS CAPTURADOS <br>
    <br> Usuario: <?php echo htmlspecialchars($_POST['usuario']); ?>.<br>
    <br> Correo: <?php echo htmlspecialchars($_POST['Correo']); ?>.<br>
    <br> Contraseña: <?php echo htmlspecialchars($_POST['contraseña']); ?>. </h3></center><br> <hr>

    <p> <h4> <a style="text-decoration:none; color:white; text-align: left; font-family: arial;" href= "index.php">  Atrás </a> </h4> 

 <script src="https://replit.com/public/js/replit-badge-v2.js" theme="dark" position="bottom-right"></script>
  </body>
</html>